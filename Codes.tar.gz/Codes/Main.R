library('igraph')
gr = as.undirected(gr)
Nodes_No = length(V(gr))
Sparsity = 2 * length(E(gr))/(Nodes_No * (Nodes_No - 1))
alpha = 0.01
#Set The number of Community
# community = 2
Membership = matrix(0,community,length(V(gr)))
#=================================Initializing By Conductance
# Con = Conductance(gr = gr,community)
# index = which(Con[1,]==0)
# for (i in 1:community) {
#   index = which(Con[i,]>0)
#   Membership[i,Con[i,index]] = 1
# }
####+================================================Initializing by Spectral Clustering
# A = get.adjacency(gr)
# D.inv = diag(1./(sqrt(apply(A, 1, sum))+1e-7));
# Laplacian = D.inv %*% A %*% D.inv;
# L.svd = svd(Laplacian);
# U.K = L.svd$u[, 1:community];
# spec.cluster = kmeans(U.K, community, nstart=10)$cluster;
# G.fit = array(0, c(Nodes_No, community));
# for(k in 1:community){
#   G.fit[spec.cluster==k, k] = 1;
# }
# Membership =  t(G.fit)
# 
# MembershipTemp = Membership
#=======================================KMEANS -- Third Iniialization
# Res = kmeans(S,community)
# Lab = Res$cluster
# for (i in 1:Nodes_No){
#   Membership[Lab[i],i] = 1
# }
############################ Extracting the Attributes of each nodes (Inherited and Generated)
# Temp = as.double(V(gr)$Inherit)
# S = matrix(0,length(V(gr)),community)
# S[,1] = Temp
# S[,2] = 1 - Temp
# F = matrix(0,length(V(gr)),community)
# F[,1] = as.double(V(gr)$Generated1)
# F[,2] = as.double(V(gr)$Generated2)
# ##################### Parameters Definition
# I = matrix(data = 0,nrow = length(S[1,]),ncol = community)
# I[1,2] = 3
# I[2,1] = 3
# W = matrix(data = 0,nrow = length(F[1,]),ncol = community)
Beta =  3 * diag(community) + 0.1
NLLVal = 0
################Updating the Hidden Variables
SecElement = matrix(0,community,1)
KHSH = matrix(0,community , 1)
DeltaLatent = matrix(0,community,Nodes_No)
for (iter in 1:2){
  Likelihood = 0
  # if (iter>20 && NLLVal[iter]>0)
  # {
  #   break
  # }
  for (i in 1:length(V(gr))){
    TempMember = 1/(1 + exp(-S%*%I))
    # TempMember = exp(1/2 * S %*%I)
    # TempMemberBeta = TempMember%*%Beta
    ############# Differentiating of L_G Respect to M_u
    Neigh = neighbors(graph = gr,v = i)
    Temp = TempMember[Neigh,]
    # Temp = colSums(Temp)
    # Temp = Membership[,Neigh]
    # Struct1 = Membership[,i]
    # Struct1 = 1/(1 + exp(- S[i,]%*%I))
    Struct1 = as.matrix(TempMember[i,])
    
    if (length(Temp)==community){
      TKDE = Beta %*% (Temp)
    }
    else
    {
      TKDE = Beta %*% t(Temp)
    }
    First =t(TKDE)%*%Struct1
    # First = t(Struct1)%*%t(TKDE)
    
    Struct = sum(First)
    Exponent = exp(-Struct)
    Likelihood = log(1-Exponent)
    Up = Exponent
    Down = 1 - Exponent
    Struct = Up/Down 
    # Prod = Beta%*% t(Temp)
    Prod = TKDE
    TotalNeigh = append(i,Neigh)
    for (j in 1:community){
      
      # SumNeigh = sum(Membership[j,TotalNeigh])
      SumNeigh = sum(TempMember[TotalNeigh,j])
      # Sum = sum(Membership[j,]) 
      Sum = sum(TempMember[,j]) 
      SecElement[j,1] = Sum - SumNeigh
      KHSH[j] = sum(Prod[j,])
    }
    # SecFinal = Sparsity * Beta%*%SecElement
    # SecFirst = Struct * KHSH
    SecFirst =  KHSH/(length(Neigh))
    SecFirst[is.na(SecFirst)] = 0
    SecSecond = (Beta%*%SecElement) /(Nodes_No - length(Neigh) - 1)
    Likelihood = Likelihood - sum(SecSecond)
    StructCoef =  (SecFirst - SecSecond)
    # StructCoef = Struct1
    # StructCoef =  SecFirst
    
    ############################### Differentiating of L_F Respect of M_u
    # Down = (1/(1+exp(-1 * S[i,]%*%I)))^2
    # Up = exp(-1 * S[i,]%*%I)
    # Inh = Up/Down
    # Difference = S[i,]%*%t(Inh)
    #     StructCoef = as.vector(Difference) * (Struct )
    # StructCoef = as.vector(Difference) * (Struct - SecFinal)
    #     MaxCol = which.max(StructCoef)
    # print(MaxCol)
    #     StructCoef[MaxCol] = abs(StructCoef[MaxCol])
    L_F1 = 1/(1 + exp(-1 * Membership[,i] %*% t(W)))
    L_F = log(L_F1)
    L_F[is.infinite(L_F)] = -30
    Likelihood  = Likelihood + F[i,] %*% t(L_F)
    L_F2 = (1 - 1/(1 + exp(-1 * Membership[,i] %*% t(W))))
    L_F = log(L_F2)
    L_F[is.infinite(L_F)] = -30
    Likelihood  = Likelihood + (1 - (F[i,] %*%  t(L_F)))
    Q = (F[i,] - 1/(1 + exp(-1 * Membership[,i] %*% t(W))))%*% W
    # DiffAtt = as.vector(Difference)%*%Q
    DiffAtt = Q
    for (j in 1:community){
      DeltaLatent[j,i]  = DeltaLatent[j,i] +  .8 * StructCoef[j] +  .2 * DiffAtt[j] 
    }
    # MaxCol = which.max(DeltaLatent[,i])
    # DeltaLatent[MaxCol,i] = abs(DeltaLatent[MaxCol,i])
  }
  # print('Updating The Latent Variable is Done')
  Membership = Membership + alpha * DeltaLatent
  ###################### Updating Parameters
  DeltaW = matrix(0,length(F[1,]),community) 
  DeltaBeta = matrix(0,community,community)
  DeltaI = matrix(0,length(S[1,]),community)
  for (i in 1:Nodes_No){
    # print(i)
    ################### Updating the I parameter Section
    if (degree(gr,i)>0){
      Neigh = neighbors(graph = gr,v = i)
      Temp = Membership[,Neigh]
      Struct1 = Membership[,i]
      First =t(Struct1)%*% Beta%*%Temp
      Struct = sum(First)
      Exponent = exp(-Struct)
      Up = Exponent
      Down = 1 - Exponent
      Struct = Up/Down 
      Prod = Beta%*% Temp
      TotalNeigh = append(i,Neigh)
      for (j in 1:community){
        SumNeigh = sum(Membership[j,TotalNeigh])
        Sum = sum(Membership[j,]) 
        SecElement[j,1] = Sum - SumNeigh
        KHSH[j] = sum(Prod[j,])
      }
      # SecFinal = Sparsity * Beta%*%SecElement
      # SecFirst = Struct * KHSH
      SecFirst =  KHSH/(length(Neigh))
      SecSecond = (Beta%*%SecElement) /(Nodes_No - length(Neigh) - 1)
      StructCoef =  (SecFirst - SecSecond)
      ############################### Differentiating of L_F Respect of M_u
      # print("StructCoef")
      # print(StructCoef)
      Q = (F[i,] - 1/(1 + exp(-1 * Membership[,i] %*% t(W))))%*% W
      FinalDifferentiationM = t(StructCoef) + Q
      # print("Q:")
      # print(Q)
      Down = (1/(1+exp(-1 * S[i,]%*%I)))^2
      Up = exp(-1 * S[i,]%*%I)
      Inh = t(Up)%*%(Down)
      # print("Inh")
      # print(Inh)
      Difference = FinalDifferentiationM %*%Inh
      Difference1 = S[i,]%*%Difference
      DeltaI = DeltaI + Difference1
    }
    #     StructCoef = as.vector(Difference) * (Struct )
    # StructCoef = as.vector(Difference) * (Struct - SecFinal)
    #     MaxCol = which.max(StructCoef)
    # print(MaxCol)
    #     StructCoef[MaxCol] = abs(StructCoef[MaxCol])
    ################### Updating The W Parameter
    CausingCurrent = F[i,]
    Temp = 1 + exp(-Membership[,i]%*%t(W))
    Temp = 1/Temp
    First = CausingCurrent - Temp
    DeltaW = DeltaW + t(First)%*%Membership[,i]  
    #===========================================##################### Updaing The Beta Parameter
    # Neigh = neighbors(graph = gr,v = i)
    # Temp = Membership[,Neigh]
    # Struct1 = Membership[,i]
    # First =t(Struct1)%*% Beta%*%Temp
    # Struct = sum(First)
    # Exponent = exp(-Struct)
    # Up = Exponent
    # Down = 1 - Exponent
    # Struct = Up/Down 
    # TotalNeigh = append(i,Neigh)
    # KHSH = matrix(0,community,1)
    # for (j in 1:community){
    #   SumNeigh = sum(Membership[j,TotalNeigh])
    #   Sum = sum(Membership[j,]) 
    #   SecElement[j,1] = Sum - SumNeigh
    #   KHSH[j] = sum(Temp[j,])
    # }
    # Prod = Struct1%*% t(KHSH)
    # # SecFinal = Sparsity * Beta%*%SecElement
    # SecFirst = Struct * Prod
    # # SecFirst =  KHSH/(length(Neigh))
    # SecSecond = (Struct1%*%t(SecElement)) /(Nodes_No - length(Neigh) - 1)
    # DeltaBeta =  DeltaBeta + (SecFirst - SecSecond)
  }
  # First = exp(-MCurrent%*%Beta%*%SumCurrent)
  # Up = as.vector(First) * MCurrent%*%t(SumCurrent)
  # Down = 1 - exp(-MCurrent%*%Beta%*%SumCurrent)
  # if (Down==0){Down = 1}
  # FirstCoef = Up/(as.vector(Down))
  # Second = MCurrent%*%t(NonNeigh)
  # DeltaBeta = DeltaBeta + FirstCoef - Second    
  # Beta  = Beta + alpha * DeltaBeta
  W = W + alpha * DeltaW
  I = I + alpha * DeltaI
  NLLVal = append(NLLVal,Likelihood)
  print("Log-Likelihood Value:")
  print(Likelihood)
  print("Iteration:")
  print(iter)
}
# I = I + alpha * DeltaI
# W = W + alpha * DeltaW
# }

###############################Evaluation Section
# 
# #############3 For Non_overlapping Graphs


#####################################
print("Evaluabtion Section")
IDX = dim(Membership)
FinalMembership = matrix(0,IDX[1],IDX[2])
#####For Lawyer
# for (i in 1:length(V(gr))){
#     idx = order(Membership[,i])
#     FinalMembership[idx[1],i] = 1
#     FinalMembership[idx[2],i] = 1
#   }


Threshold = -log2(1 - 1/Nodes_No)
Threshold = Threshold^(1/20000)
SSS2 = matrix(0,community,length(V(graph = gr)))
for (j in 1:community){
  SSS2[j,Membership[j,]>Threshold] =  1
}

# IDX = dim(Membership)
# FinalMembership = matrix(0,IDX[1],IDX[2])
for (j in 1:length(V(gr))){
  index = which.max(Membership[,j])
  FinalMembership[index,j] = 1
}

# Result = final(final_class = FinalMembership,truth = truth)
# # print(compare(Result,t(S),'nmi'))
# Result = final(final_class = FinalMembership,truth = ground)
print(compare(Result,truth,'nmi'))

# FMeasure = f1_score(gr,Result,truth,community)
# compare(SSS,t(S),'nmi')
# f1_score(gr,SSS,t(S),community)
# compare(SSS2,t(S),'nmi')
# f1_score(gr,SSS2,t(S),community)
# compare(final12,t(S),'nmi')
# f1_score(gr,final12,t(S),community)