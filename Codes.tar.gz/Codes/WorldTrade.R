library('igraph')
gr = read.graph('WorldTrade.gml',format = 'gml')
Inherit = as.vector(V(gr)$Inherit)
G1 = as.vector(V(gr)$Generated1)
G2 = as.vector(V(gr)$Generated2)
S = matrix(0,length(V(gr)),5)
community = 5
for (i in 1:5){
  IDX = i
  if (i == 5)
  {
    IDX = 6
  }
  index = which(Inherit == IDX)
  S[index,i] = 1
}
F = matrix(0,length(V(gr)),8)
for (i in 1:5){
  IDX = i
  if (i==5)
  {
    IDX = 9999998
  }
  index = which(G1==IDX)
  F[index,i] = 1
}
for (i in 1:3){
  IDX = i
  index = which(G2==IDX)
  F[index,i+5] = 1
}
# F = S
truth = t(S)
I = matrix(0,length(S[1,]),community)
I = diag(community) * 10
W = matrix(0,length(F[1,]),community)
# W = I
# F = S
# W = I
F[,] = 0
